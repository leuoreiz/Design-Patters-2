# Avaliação — Padrões de Projetos

Nome completo: Leonardo Reis de Campos  
Turma: 1

## Questão 1 — Factory Method

Apolice é o produto abstrato; ApoliceAuto, ApoliceResidencial e ApoliceVida são os produtos concretos. EmissorApolice é o criador e criarApolice é o Factory Method. Os emissores especializados implementam esse método.

O procedimento final emitir cria, calcula e imprime uma única vez, usando somente Apolice. Main instancia emissores, sem instanciar apólices ou selecionar produtos com if/switch. Para adicionar Viagem, basta criar ApoliceViagem e EmissorViagem; o procedimento e as classes existentes permanecem intactos. Um novo cliente pode usar o novo emissor.

Valores demonstrados: Auto 60000 → R$ 400,00/mês; Residencial 400000 → R$ 500,00/mês; Vida 200000 → R$ 500,00/mês.

## Questão 2 — Abstract Factory

FabricaCheckout cria uma família de três produtos abstratos: DocumentoFiscal, Pagamento e EtiquetaEnvio. FabricaBrasil e FabricaAlemanha produzem as respectivas famílias. Checkout recebe apenas uma fábrica pelo construtor e não recebe produtos separados.

Os parâmetros genéricos P extends Pais reforçam a consistência em compilação: a fábrica brasileira retorna somente produtos tipados com Brasil; a alemã, com Alemanha. Por exemplo, retornar DeutschePost em criarEtiquetaEnvio de FabricaBrasil causa erro de compilação. Não usar tipos raw nem casts não verificados, que contornam a segurança dos genéricos.

Um novo país exige um marcador de país, três produtos e uma fábrica novos, sem alterar Checkout. Os métodos de pagamento e etiqueta representam os artefatos por descrição, conforme a simulação solicitada; não fazem integrações reais.

Para pedidos de base 1000, os impostos são 180,00 no Brasil e 190,00 na Alemanha. A base é demonstrativa na moeda local; não há conversão cambial. O relatório informa os três artefatos.

O diagrama UML editável está em questao2/diagrama/checkout.drawio. Abra no diagrams.net. Há também uma versão PlantUML.

## Compilar e executar (JDK 8 ou superior)

Execute na raiz do projeto, mantendo as questões em diretórios de saída separados porque ambas têm classe Main:

```sh
mkdir -p questao1/out questao2/out
javac -encoding UTF-8 -d questao1/out questao1/src/*.java
java -cp questao1/out Main
javac -encoding UTF-8 -d questao2/out questao2/src/*.java
java -cp questao2/out Main
```

## Entrega

O ZIP contém os fontes, não um envio ao repositório remoto. Extraia e envie ao repositório indicado pela avaliação antes do prazo. Confira nome e turma. Os critérios finais da questão 2 não foram fornecidos no texto recebido; a solução segue todos os requisitos e entregáveis visíveis.
