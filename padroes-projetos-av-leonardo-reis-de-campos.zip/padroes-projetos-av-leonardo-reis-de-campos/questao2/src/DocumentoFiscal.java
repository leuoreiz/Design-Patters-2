public interface DocumentoFiscal<P extends Pais> { String descrever(); }
