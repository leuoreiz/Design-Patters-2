public final class Pix implements Pagamento<Brasil> {
    public String descrever() { return "Pagamento via Pix"; }
}
