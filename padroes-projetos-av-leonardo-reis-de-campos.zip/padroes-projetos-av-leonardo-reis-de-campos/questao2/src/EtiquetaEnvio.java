public interface EtiquetaEnvio<P extends Pais> { String descrever(); }
