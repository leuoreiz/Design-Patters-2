public interface FabricaCheckout<P extends Pais> {
    DocumentoFiscal<P> criarDocumentoFiscal(double valorPedido);
    Pagamento<P> criarPagamento();
    EtiquetaEnvio<P> criarEtiquetaEnvio();
}
