import java.util.Objects;

public final class Checkout<P extends Pais> {
    private final FabricaCheckout<P> fabrica;
    public Checkout(FabricaCheckout<P> fabrica) {
        this.fabrica = Objects.requireNonNull(fabrica);
    }
    public void finalizarPedido(double valorPedido) {
        DocumentoFiscal<P> documento = fabrica.criarDocumentoFiscal(valorPedido);
        Pagamento<P> pagamento = fabrica.criarPagamento();
        EtiquetaEnvio<P> etiqueta = fabrica.criarEtiquetaEnvio();
        System.out.println(documento.descrever());
        System.out.println(pagamento.descrever());
        System.out.println(etiqueta.descrever());
        System.out.println();
    }
}
