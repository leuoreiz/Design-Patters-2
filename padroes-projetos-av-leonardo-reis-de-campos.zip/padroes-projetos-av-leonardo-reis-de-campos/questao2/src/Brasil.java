public final class Brasil implements Pais { private Brasil() {} }
