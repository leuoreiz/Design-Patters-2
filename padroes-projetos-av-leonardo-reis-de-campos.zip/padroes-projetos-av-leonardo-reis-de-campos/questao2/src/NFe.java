import java.util.Locale;

public final class NFe implements DocumentoFiscal<Brasil> {
    private final double valorPedido;
    public NFe(double valorPedido) { this.valorPedido = valorPedido; }
    public String descrever() {
        return String.format(new Locale("pt", "BR"),
            "NF-e — ICMS de 18%%; base: %.2f; imposto: %.2f", valorPedido, valorPedido * 0.18);
    }
}
