public interface Pagamento<P extends Pais> { String descrever(); }
