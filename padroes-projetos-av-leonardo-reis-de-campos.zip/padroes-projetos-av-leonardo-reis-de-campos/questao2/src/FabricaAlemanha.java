public final class FabricaAlemanha implements FabricaCheckout<Alemanha> {
    public DocumentoFiscal<Alemanha> criarDocumentoFiscal(double valorPedido) {
        return new VatInvoice(valorPedido);
    }
    public Pagamento<Alemanha> criarPagamento() { return new SepaDirectDebit(); }
    public EtiquetaEnvio<Alemanha> criarEtiquetaEnvio() { return new DeutschePost(); }
}
