public final class DeutschePost implements EtiquetaEnvio<Alemanha> {
    public String descrever() { return "Etiqueta de envio da Deutsche Post"; }
}
