public interface Pais {}
