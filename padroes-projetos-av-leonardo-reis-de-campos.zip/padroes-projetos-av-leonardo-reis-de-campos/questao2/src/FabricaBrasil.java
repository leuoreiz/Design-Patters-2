public final class FabricaBrasil implements FabricaCheckout<Brasil> {
    public DocumentoFiscal<Brasil> criarDocumentoFiscal(double valorPedido) {
        return new NFe(valorPedido);
    }
    public Pagamento<Brasil> criarPagamento() { return new Pix(); }
    public EtiquetaEnvio<Brasil> criarEtiquetaEnvio() { return new Correios(); }
}
