import java.util.Locale;

public final class VatInvoice implements DocumentoFiscal<Alemanha> {
    private final double valorPedido;
    public VatInvoice(double valorPedido) { this.valorPedido = valorPedido; }
    public String descrever() {
        return String.format(new Locale("pt", "BR"),
            "VAT invoice — imposto de 19%%; base: %.2f; imposto: %.2f", valorPedido, valorPedido * 0.19);
    }
}
