public final class Correios implements EtiquetaEnvio<Brasil> {
    public String descrever() { return "Etiqueta de envio dos Correios"; }
}
