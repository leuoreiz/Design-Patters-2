public final class Alemanha implements Pais { private Alemanha() {} }
