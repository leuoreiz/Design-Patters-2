public class Main {
    public static void main(String[] args) {
        Checkout<Brasil> brasil = new Checkout<>(new FabricaBrasil());
        Checkout<Alemanha> alemanha = new Checkout<>(new FabricaAlemanha());
        System.out.println("Pedido — Brasil");
        brasil.finalizarPedido(1000);
        System.out.println("Pedido — Alemanha");
        alemanha.finalizarPedido(1000);
    }
}
