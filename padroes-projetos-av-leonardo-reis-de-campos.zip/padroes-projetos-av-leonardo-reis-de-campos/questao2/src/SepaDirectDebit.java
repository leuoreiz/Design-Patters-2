public final class SepaDirectDebit implements Pagamento<Alemanha> {
    public String descrever() { return "Pagamento via SEPA Direct Debit"; }
}
