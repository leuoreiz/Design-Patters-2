public final class ApoliceVida implements Apolice {
    private final String segurado;
    private final double capitalSegurado;
    public ApoliceVida(String segurado, double capitalSegurado) {
        this.segurado = segurado;
        this.capitalSegurado = capitalSegurado;
    }
    public String getLinha() { return "Vida"; }
    public String getSegurado() { return segurado; }
    public double calcularPremioMensal() { return capitalSegurado * 0.03 / 12; }
    public String getDocumentos() { return "Documento de identidade e CPF"; }
}
