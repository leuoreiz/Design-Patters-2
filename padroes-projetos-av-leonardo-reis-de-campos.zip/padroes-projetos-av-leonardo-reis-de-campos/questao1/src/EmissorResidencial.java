public final class EmissorResidencial extends EmissorApolice {
    @Override
    protected Apolice criarApolice(String segurado, double valor) {
        return new ApoliceResidencial(segurado, valor);
    }
}
