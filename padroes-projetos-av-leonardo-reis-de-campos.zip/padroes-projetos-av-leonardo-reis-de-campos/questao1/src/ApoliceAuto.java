public final class ApoliceAuto implements Apolice {
    private final String segurado;
    private final double valorVeiculo;
    public ApoliceAuto(String segurado, double valorVeiculo) {
        this.segurado = segurado;
        this.valorVeiculo = valorVeiculo;
    }
    public String getLinha() { return "Auto"; }
    public String getSegurado() { return segurado; }
    public double calcularPremioMensal() { return valorVeiculo * 0.08 / 12; }
    public String getDocumentos() { return "CNH e CRLV"; }
}
