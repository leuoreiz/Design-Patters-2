import java.util.Locale;

public abstract class EmissorApolice {
    protected abstract Apolice criarApolice(String segurado, double valor);

    public final void emitir(String segurado, double valor) {
        Apolice apolice = criarApolice(segurado, valor);
        double premio = apolice.calcularPremioMensal();
        System.out.println("Linha: " + apolice.getLinha());
        System.out.println("Segurado: " + apolice.getSegurado());
        System.out.printf(new Locale("pt", "BR"), "Prêmio mensal: R$ %.2f%n", premio);
        System.out.println("Documentos: " + apolice.getDocumentos());
        System.out.println();
    }
}
