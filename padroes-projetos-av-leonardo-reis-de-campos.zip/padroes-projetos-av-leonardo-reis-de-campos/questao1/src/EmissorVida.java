public final class EmissorVida extends EmissorApolice {
    @Override
    protected Apolice criarApolice(String segurado, double valor) {
        return new ApoliceVida(segurado, valor);
    }
}
