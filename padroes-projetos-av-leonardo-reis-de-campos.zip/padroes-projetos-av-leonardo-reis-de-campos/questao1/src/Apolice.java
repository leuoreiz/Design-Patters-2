public interface Apolice {
    String getLinha();
    String getSegurado();
    double calcularPremioMensal();
    String getDocumentos();
}
