public final class EmissorAuto extends EmissorApolice {
    @Override
    protected Apolice criarApolice(String segurado, double valor) {
        return new ApoliceAuto(segurado, valor);
    }
}
