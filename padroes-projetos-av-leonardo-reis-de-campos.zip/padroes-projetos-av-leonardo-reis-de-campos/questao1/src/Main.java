public class Main {
    public static void main(String[] args) {
        EmissorApolice auto = new EmissorAuto();
        EmissorApolice residencial = new EmissorResidencial();
        EmissorApolice vida = new EmissorVida();
        auto.emitir("Leonardo Reis de Campos", 60000);
        residencial.emitir("Ana Silva", 400000);
        vida.emitir("Carlos Souza", 200000);
    }
}
