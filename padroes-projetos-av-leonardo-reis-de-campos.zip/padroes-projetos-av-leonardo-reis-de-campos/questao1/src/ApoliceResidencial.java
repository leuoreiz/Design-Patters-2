public final class ApoliceResidencial implements Apolice {
    private final String segurado;
    private final double valorImovel;
    public ApoliceResidencial(String segurado, double valorImovel) {
        this.segurado = segurado;
        this.valorImovel = valorImovel;
    }
    public String getLinha() { return "Residencial"; }
    public String getSegurado() { return segurado; }
    public double calcularPremioMensal() { return valorImovel * 0.015 / 12; }
    public String getDocumentos() { return "Escritura ou contrato de locação"; }
}
